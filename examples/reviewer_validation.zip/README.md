# Reviewer-validation examples: six abundant haplotypes per dataset

These deterministic synthetic datasets were redesigned for manuscript/reviewer validation. Each example has approximately 20 variant records and is built around **six known major haplotypes**. In the intended EasyHap mode, all six are observed in **more than five accessions** and also exceed **5% frequency**.

## Dataset design

| Dataset | Samples | Variant records | Intended mode | Ground-truth expectation |
|---|---:|---:|---|---|
| `diploid_unphased.vcf` | 42 | 20 | `genotype` | 6 major haplotypes; Six moderate-heterozygosity unphased multilocus genotype haplotypes; 7 accessions each. |
| `diploid_high_heterozygosity_unphased.vcf` | 42 | 20 | `genotype` | 6 major haplotypes; Six highly heterozygous unphased genotype haplotypes; copy mode must reject. |
| `diploid_low_heterozygosity.vcf` | 42 | 20 | `genotype` | 6 major haplotypes; Six low-heterozygosity/selfing-like genotype haplotypes; 7 accessions each. |
| `diploid_phased_heterozygous.vcf` | 36 | 20 | `copy` | 6 major haplotypes; Six phased chromosome-copy haplotypes; each present in 12 accessions. |
| `autotetraploid.vcf` | 36 | 20 | `copy` | 6 major haplotypes; Six phased chromosome-copy haplotypes in four-copy genotypes; each abundant. |
| `allotetraploid_subgenomes.vcf` | 36 | 20 | `copy` | 6 major haplotypes; Ten A-subgenome + ten B-subgenome sites; each subgenome separately has six abundant haplotypes. |
| `large_deletion.vcf` | 36 | 20 | `copy` | 6 major haplotypes; Six copy haplotypes including two deletion-bearing haplotypes; ABS and ordinary missing are distinct. |
| `multiallelic_overlap.vcf` | 36 | 20 | `copy` | 6 major haplotypes; Six copy haplotypes across multiallelic, same-start, and deletion-nested records. |
| `plink_toy.bed/.bim/.fam` | 42 | 20 | `genotype` | 6 major haplotypes; Six unphased PLINK multilocus genotype haplotypes; 7 accessions each. |

Each dataset also has a matching `.gff3` file with gene, transcript, exon, CDS, and UTR features for testing gene-structure visualization. The exact EasyHap-observed counts are recorded in `EXPECTED_HAPLOTYPE_FREQUENCIES.tsv` after validation.

## Suggested commands

```bash
# Moderate unphased diploid
easyhap analyze --vcf diploid_unphased.vcf --group diploid_unphased.groups.tsv --gff diploid_unphased.gff3 --region Chr1:1-4000 --mode genotype --plot --plot-format pdf,png --outdir out_unphased

# Highly heterozygous unphased diploid: genotype mode works
easyhap analyze --vcf diploid_high_heterozygosity_unphased.vcf --group diploid_high_heterozygosity_unphased.groups.tsv --gff diploid_high_heterozygosity_unphased.gff3 --region Chr1:1-4000 --mode genotype --plot --plot-format pdf,png --outdir out_highhet
# The same file in copy mode should be rejected because heterozygous GTs are unphased.

# set iupac
easyhap analyze --vcf diploid_high_heterozygosity_unphased.vcf --group diploid_high_heterozygosity_unphased.groups.tsv --gff diploid_high_heterozygosity_unphased.gff3 --region Chr1:1-4000 --mode genotype --hetero-policy iupac  --plot --plot-format pdf,png --outdir out_highhet_iupac

# Low-heterozygosity/selfing-like diploid
easyhap analyze --vcf diploid_low_heterozygosity.vcf --group diploid_low_heterozygosity.groups.tsv --gff diploid_low_heterozygosity.gff3 --region Chr1:1-4000 --mode genotype --plot --plot-format pdf,png --outdir out_lowhet

# Phased diploid
easyhap analyze --vcf diploid_phased_heterozygous.vcf --group diploid_phased_heterozygous.groups.tsv --gff diploid_phased_heterozygous.gff3 --region Chr1:1-4000 --mode copy --plot --plot-format pdf,png --outdir out_phased

# Autotetraploid
easyhap analyze --vcf autotetraploid.vcf --group autotetraploid.groups.tsv --gff autotetraploid.gff3 --region Chr1:1-4000 --mode copy --plot --plot-format pdf,png --outdir out_auto4x

# Allotetraploid: analyze the two subgenomes separately
easyhap analyze --vcf allotetraploid_subgenomes.vcf --group allotetraploid_subgenomes.groups.tsv --gff allotetraploid_subgenomes.gff3 --region ChrA01:1-3000 --mode copy --plot --plot-format pdf,png --outdir out_allo_A
easyhap analyze --vcf allotetraploid_subgenomes.vcf --group allotetraploid_subgenomes.groups.tsv --gff allotetraploid_subgenomes.gff3 --region ChrB01:1-3000 --mode copy --plot --plot-format pdf,png --outdir out_allo_B

# Large deletion / genomic absence
easyhap analyze --vcf large_deletion.vcf --group large_deletion.groups.tsv --gff large_deletion.gff3 --region Chr1:1-7000 --mode copy --plot --plot-format pdf,png --outdir out_large_del

# Multiallelic + overlapping variants
easyhap analyze --vcf multiallelic_overlap.vcf --group multiallelic_overlap.groups.tsv --gff multiallelic_overlap.gff3 --region Chr1:1-5000 --mode copy --plot --plot-format pdf,png --outdir out_overlap

# PLINK 1 binary input
easyhap analyze --bfile plink_toy --group plink_toy.groups.tsv --gff plink_toy.gff3 --region 1:1-5000 --mode genotype --plot --plot-format pdf,png --outdir out_plink
```

## Important interpretation

The datasets are controlled software-validation examples, not demographic simulations. The six common haplotypes are deliberately balanced so that algorithmic behavior is easy to audit. The large-deletion dataset contains two deletion-bearing haplotypes; markers within the deleted interval become `ABS` only on deletion-supported chromosome copies. A separate ordinary missing call outside the deletion remains `N`.
